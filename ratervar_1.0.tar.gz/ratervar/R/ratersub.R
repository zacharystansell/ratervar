ratersub <-
function(data, formula, subset="Year==1",  b = 10, rank = TRUE, diff = TRUE, rela = TRUE){
  mc <- mcout <- match.call()
  formula<-as.formula(mc$formula)
  #split data into year 1 and 2
 if (!is.null(subset)){
   subsetdata<-subset(data, eval(parse(text=mc$subset)))
 } else {subsetdata<-data}
  

  
  leaps<- leaps::regsubsets(formula, data=subsetdata)
  return(leaps)
}
