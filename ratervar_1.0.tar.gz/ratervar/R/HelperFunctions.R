
plot.ratervarclass <-
  function(x,rater=NULL,...){
    if ((length(x[[1]])>1)){
      raternames=names(x[[1]])
     if (is.null(rater)){
       warning("you didnt specify a rater, first rater is used.")
       rater<-raternames[1]
     } else { if (!(rater%in%raternames)){
       stop(paste("A rater with name ", rater, " doesn't exist in ratervarobject.", sep=""))
     }
       }
    }
    if (length(x[[1]])==1){ 
      if (!is.null(rater)){
      stop("rater doesn't exist")
      }
    }
    if (is.null(rater)){
    suppressWarnings(plot(booteval.relimp(x$bootlist[[1]],sort=TRUE),main=paste("Rater: ", names(x$bootlist[[1]]), sep=""))) # plot result 
    } else {
      listnum<-which(names(x$bootlist)%in%rater)
      suppressWarnings(plot(booteval.relimp(x$bootlist[[listnum]],sort=TRUE),main=paste("Rater: ", rater, sep=""))) # plot result 
    }
  }






summary.ratervarclass <-
  function(object,rater=NULL,...){
    if ((length(object[[1]])>1)){
      raternames=names(object[[1]])
      if (is.null(rater)){
        warning("you didnt specify a rater, first rater is used.")
        rater<-raternames[1]
      } else { if (!(rater%in%raternames)){
        stop(paste("A rater with name ", rater, " doesn't exist in ratervarobject.", sep=""))
      }
      }
    }
    if (length(object[[1]])==1){ 
      if (!is.null(rater)){
        stop("rater doesn't exist")
      }
    }
    if (is.null(rater)){
      print(paste("Rater: ", names(object$bootlist[[1]]), sep=""))
      suppressWarnings(print(booteval.relimp(object$bootlist[[1]]))) # plot result 
    } else {
      listnum<-which(names(object$bootlist)%in%rater)
      print(paste("Rater: ", rater, sep=""))
      suppressWarnings(print(booteval.relimp(object$bootlist[[listnum]]))) # plot result 
    }
  }





