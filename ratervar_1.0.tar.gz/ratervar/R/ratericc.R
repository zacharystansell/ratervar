ratericc <-
function(data, idcols, subset=NULL,formula=Planting+Plot~Rater, qcol,type="c", unit="s",model="t", r0=0,...){
  mc <- mcout <- match.call()
  formula<-as.formula(paste(as.character(c(mc$formula)), "+variable", sep=""))
  
  data<-cbind(data[,(idcols)], data[,(qcol)])
  
  #split data into year 1 and 2
  if (!is.null(subset)){
    data<-subset(data, eval(parse(text=mc$subset)))
  } 
  
  meltedsubsetdata<-reshape2::melt(data, id=idcols)
  castedmeltedsubsetdata<-reshape2::acast(meltedsubsetdata, formula, fun.aggregate=mean)
  outfunc=irr::icc(castedmeltedsubsetdata,type=type, unit=unit,model=model, r0=r0,...)
  return(outfunc)
}
