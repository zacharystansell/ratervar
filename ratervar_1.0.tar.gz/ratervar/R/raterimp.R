raterimp <-
function(data, formula,  colforraters,subset=NULL, byrater=TRUE, b = 1000, atype = "lmg", rank = TRUE, diff = TRUE, rela = TRUE){
  if (!is.data.frame(data)){
    stop("data must be a data frame object")
  }
  if (!(atype%in%c("lmg","pmvd", "last"))){
    stop("atype needs to be one of 'lmg', 'pmvd', 'last'")
  }
  
  mc <- mcout <- match.call()
  formula<-as.formula(mc$formula)
  
  variablesinformula<-all.vars(formula)
  
  if (sum(variablesinformula%in%colnames(data))<length(variablesinformula)){
    varsnotindata<-variablesinformula[which(!(variablesinformula%in%colnames(data)))]
    stop(paste(paste(varsnotindata, sep=","), "not in data. ", sep=" "))
  }
  
#split data into year 1 and 2
  if (is.null(subset)){
    subsetdata=data
  }else {
    subsetdata<-subset(data, eval(parse(text=mc$subset)))
  }
####################################################################################
#What are the "biases" for each particular rater? Looking at year 1 data:
####################################################################################

#####one function...
####handles all raters..
####input rvY1
####

if (byrater){
#Divide the data by each individual rater:
ratersindata<-levels(subsetdata[,colnames(subsetdata)%in%colforraters])
ratersdata<-split(subsetdata,subsetdata[,colnames(subsetdata)%in%colforraters])

typetoput<-atype
fitslist<- lapply(1:length(ratersindata), function(r){lm(formula, data=ratersdata[[r]])})
bootlist<-lapply(1:length(ratersindata), function(r){suppressWarnings(relaimpo::boot.relimp(fitslist[[r]], b = b, type = atype, rank = rank, diff = diff, rela = rela))})
bootevallist<-lapply(1:length(ratersindata), function(r){suppressWarnings(relaimpo::booteval.relimp(bootlist[[r]],typesel=typetoput, sort=TRUE))})
names(bootlist)<-names(bootevallist)<-ratersindata
#Calculate relative importance for each rater:
#need to change b=1000 (using 100 just for time reasons)

names(bootevallist)<-names(bootlist)<-ratersindata
out<-list(bootlist=bootlist, bootevallist=bootevallist)
class(out)<-"ratervarclass"
return(out)
} 
if (!byrater){
  fitslist<- lm(formula, data = subsetdata)
  bootlist<-list(suppressWarnings(relaimpo::boot.relimp(fitslist, b = b, type = atype, rank = rank, diff = diff, rela = rela)))
  #Calculate relative importance for each rater:
  #need to change b=1000 (using 100 just for time reasons)
  typetoput<-atype
  bootevallist<-list(suppressWarnings(relaimpo::booteval.relimp(bootlist[[1]],typesel=typetoput,sort=TRUE)))
  out<-list(bootlist=bootlist, bootevallist=bootevallist)
  class(out)<-"ratervarclass"
  return(out)
}  
}
