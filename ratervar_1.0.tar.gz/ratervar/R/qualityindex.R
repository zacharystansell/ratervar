qualityindex <-
function(data,traits,weights,normalize=T){
  if (sum(colnames(data)%in%traits)!=length(traits)){stop("Some traits do not exist in data")}
  if (class(weights)%in%"ratervarclass"){
    lengthlist<-length(weights[[2]])
    outmat<-NULL
    for (i in 1:lengthlist){
     traitsinmodel<-rownames(attributes(weights[[2]][[i]])$ave.coeffs)
     weightsfunc1<- attributes(weights[[2]][[i]])$lmg
     weightsfunc2<- attributes(weights[[2]][[i]])$pmvd
     weightsfunc<-c(weightsfunc1,weightsfunc2)
     names(weightsfunc)<-traitsinmodel
     weightsfunc<-weightsfunc[names(weightsfunc)%in%traits]
     weightsfunc<-weightsfunc[match(traits,names(weightsfunc))]
     datatraits<-data[,colnames(data)%in%traits]
     datatraits<-datatraits[,match(traits,colnames(datatraits))]
     newvar<-as.matrix(datatraits)%*%weightsfunc
     outmat<-cbind(outmat,newvar)
    }
    colnames(outmat)<-names(weights[[2]])
    return(outmat)
   } else if (is.numeric(weights)){
    if (length(weights)!=length(traits)){stop("Number of weights should be the same as the number of traits")}
     
 if (normalize){weights<-weights/sum(weights)}
  datatraits<-data[,colnames(data)%in%traits]
  datatraits<-datatraits[,match(traits,colnames(datatraits))]
  newvar<-as.matrix(datatraits)%*%weights
  return(newvar)
  
} else {stop("the weights should be either a vector of weights or a 'ratervarclass' abject.")}

}
